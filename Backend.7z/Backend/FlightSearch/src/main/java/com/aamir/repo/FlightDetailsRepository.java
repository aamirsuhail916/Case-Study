package com.aamir.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.aamir.model.FlightDetails;

public interface FlightDetailsRepository extends MongoRepository<FlightDetails, String> {

}