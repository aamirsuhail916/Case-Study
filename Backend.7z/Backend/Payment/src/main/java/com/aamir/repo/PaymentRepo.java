package com.aamir.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.aamir.model.Payment;

public interface PaymentRepo extends MongoRepository<Payment, String> {

}
