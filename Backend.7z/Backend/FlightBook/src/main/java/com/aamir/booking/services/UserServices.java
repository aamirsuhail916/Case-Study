package com.aamir.booking.services;

import com.aamir.booking.repository.SeatAvalibilityRepo;
import com.aamir.booking.repository.UserModelRepository;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.aamir.booking.model.SeatAvailability;
import com.aamir.booking.model.UserModel;

@Service
public class UserServices {

	@Autowired
    UserModelRepository userRepository;

	@Autowired
    SeatAvalibilityRepo seatAvalibilityRepo;

	// Adding data to user collection
	public String saveUserDetail(UserModel u) {
		System.out.println(u.getNoOfPassengers());
		SeatAvailability flightseat = seatAvalibilityRepo.findById(u.getFlightId()).get();
		System.out.println(flightseat);
		System.out.println(flightseat.getAvailable());

		if (u.getNoOfPassengers() <= flightseat.getAvailable()) {
			userRepository.save(u);
			int updatedseats = flightseat.getAvailable() - u.getNoOfPassengers();
			flightseat.available = updatedseats;

			seatAvalibilityRepo.save(flightseat);
			return ("FlightId : " + u.getFlightId() + " Booking Id : " + u.getBookingid() + " Seats Booked : "
					+ u.getNoOfPassengers());
		
		} else {
			return "Seats Not Avaliable";
		}

	}

	// User details of particular user by id
	public UserModel getUserDetailsByName(String id) {
		return userRepository.findById(id).get();
	}

}
